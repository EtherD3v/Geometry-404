# Jumping Square Game

> Simple vanilla javascript game inspired by Geometry Dash

You can play the game here [www.jumping-square-game.web.app](https://jumping-square-game.web.app/)
